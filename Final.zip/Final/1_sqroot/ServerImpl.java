import java.rmi.*;
import java.rmi.server.*;

public class ServerImpl extends UnicastRemoteObject implements ServerIntf {

    public ServerImpl() throws RemoteException {
    }

    public double calculateSquareRoot(double number) throws RemoteException {
        double result = Math.sqrt(number);
        return result;
    }
}

