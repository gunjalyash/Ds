import java.rmi.*;

interface ServerIntf extends Remote {
    public double calculateSquareRoot(double number) throws RemoteException;
}

