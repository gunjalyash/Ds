import java.rmi.*;

interface ServerIntf extends Remote {
    public boolean areStringsEqual(String str1, String str2) throws RemoteException;
}

