import java.rmi.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            String serverURL = "rmi://localhost/Server";
            ServerIntf serverIntf = (ServerIntf) Naming.lookup(serverURL);

            System.out.print("Enter first string: ");
            String str1 = sc.nextLine();

            System.out.print("Enter second string: ");
            String str2 = sc.nextLine();

            System.out.println("--------------- Results ---------------");
            if (serverIntf.areStringsEqual(str1, str2)) {
                System.out.println("The strings are equal.");
            } else {
                System.out.println("The strings are not equal.");
            }

        } catch (Exception e) {
            System.out.println("Exception Occurred At Client!" + e.getMessage());
        }
    }
}

