import CalculatorModule.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;

class CalculatorServer {
    public static void main(String[] args) {
        try {
            // initialize the ORB
            ORB orb = ORB.init(args, null);
            // initialize the POA
            POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootPOA.the_POAManager().activate();
            // create the calculator object
            CalculatorImpl calc = new CalculatorImpl();
            // get the object reference from the servant class
            org.omg.CORBA.Object ref = rootPOA.servant_to_reference(calc);
            Calculator h_ref = CalculatorModule.CalculatorHelper.narrow(ref);
            // resolve the NameService
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            // bind the calculator object to the NameService
            NameComponent path[] = ncRef.to_name("Calculator");
            ncRef.rebind(path, h_ref);
            System.out.println("Calculator Server is running...");
            orb.run();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

