import CalculatorModule.CalculatorPOA;

class CalculatorImpl extends CalculatorPOA {
    CalculatorImpl() {
        super();
        System.out.println("Calculator Object Created");
    }

    public float add(float num1, float num2) {
        return num1 + num2;
    }

    public float subtract(float num1, float num2) {
        return num1 - num2;
    }

    public float multiply(float num1, float num2) {
        return num1 * num2;
    }

    public float divide(float num1, float num2) throws CalculatorModule.DivideByZero {
        if(num2 == 0)
            throw new CalculatorModule.DivideByZero();
        return num1 / num2;
    }
}

