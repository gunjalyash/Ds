import CalculatorModule.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import java.io.*;

class CalculatorClient {
    public static void main(String args[]) {
        try {
            // initialize the ORB
            ORB orb = ORB.init(args, null);
            // resolve the NameService
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            // narrow down to the Calculator object
            Calculator calc = CalculatorHelper.narrow(ncRef.resolve_str("Calculator"));
            // perform calculator operations
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter first number: ");
            float num1 = Float.parseFloat(br.readLine());
            System.out.print("Enter second number: ");
            float num2 = Float.parseFloat(br.readLine());
            System.out.println("Addition: " + calc.add(num1, num2));
            System.out.println("Subtraction: " + calc.subtract(num1, num2));
            System.out.println("Multiplication: " + calc.multiply(num1, num2));
            try {
                System.out.println("Division: " + calc.divide(num1, num2));
            } catch (CalculatorModule.DivideByZero e) {
                System.out.println("Cannot divide by zero!");
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}





