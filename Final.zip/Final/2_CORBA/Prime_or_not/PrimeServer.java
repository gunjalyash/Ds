import PrimeModule.Prime;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;

class PrimeServer {
    public static void main(String[] args) {
        try {
            org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args, null);
            POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootPOA.the_POAManager().activate();

            PrimeImpl primeImpl = new PrimeImpl();
            org.omg.CORBA.Object ref = rootPOA.servant_to_reference(primeImpl);
            Prime h_ref = PrimeModule.PrimeHelper.narrow(ref);

            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);

            String name = "Prime";
            NameComponent path[] = ncRef.to_name(name);
            ncRef.rebind(path, h_ref);

            System.out.println("Prime Server is running and waiting...");
            orb.run();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

