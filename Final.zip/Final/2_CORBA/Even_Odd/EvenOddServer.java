import EvenOddModule.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;

class EvenOddServer {
    public static void main(String[] args) {
        try {
            // initialize the ORB
            ORB orb = ORB.init(args, null);
            // initialize the POA
            POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootPOA.the_POAManager().activate();
            // create the EvenOdd object
            EvenOddImpl evenOdd = new EvenOddImpl();
            // get the object reference from the servant class
            org.omg.CORBA.Object ref = rootPOA.servant_to_reference(evenOdd);
            EvenOdd h_ref = EvenOddModule.EvenOddHelper.narrow(ref);
            // resolve the NameService
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            // bind the EvenOdd object to the NameService
            NameComponent path[] = ncRef.to_name("EvenOdd");
            ncRef.rebind(path, h_ref);
            System.out.println("EvenOdd Server is running...");
            orb.run();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

