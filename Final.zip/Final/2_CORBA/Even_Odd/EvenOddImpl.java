import EvenOddModule.EvenOddPOA;

class EvenOddImpl extends EvenOddPOA {
    EvenOddImpl() {
        super();
        System.out.println("EvenOdd Object Created");
    }

    public String checkEvenOrOdd(long number) {
        if (number % 2 == 0) {
            return "The number is even";
        } else {
            return "The number is odd";
        }
    }
    
    // Override the method with the correct signature
    public String checkEvenOrOdd(int number) {
        return checkEvenOrOdd((long)number);
    }
}

