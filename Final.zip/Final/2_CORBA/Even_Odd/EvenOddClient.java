import EvenOddModule.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import java.io.*;

class EvenOddClient {
    public static void main(String args[]) {
        try {
            // initialize the ORB
            ORB orb = ORB.init(args, null);
            // resolve the NameService
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            // narrow down to the EvenOdd object
            EvenOdd evenOdd = EvenOddHelper.narrow(ncRef.resolve_str("EvenOdd"));
            // perform even-odd check
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a number: ");
            long num = Long.parseLong(br.readLine());
            // Cast the long value to int before passing it to the method
            System.out.println(evenOdd.checkEvenOrOdd((int) num));
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

