import java.rmi.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            String serverURL = "rmi://localhost/Server";
            ServerIntf serverIntf = (ServerIntf) Naming.lookup(serverURL);

            System.out.print("Enter First Number: ");
            int num1 = sc.nextInt();

            System.out.print("Enter Second Number: ");
            int num2 = sc.nextInt();

            System.out.println("--------------- Results ---------------");
            System.out.println("Result of Substration: " + serverIntf.addNumbers(num1, num2));

        } catch (Exception e) {
            System.out.println("Exception Occurred At Client!" + e.getMessage());
        }
    }
}

