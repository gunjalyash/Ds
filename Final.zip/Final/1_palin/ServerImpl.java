import java.rmi.*;
import java.rmi.server.*;

public class ServerImpl extends UnicastRemoteObject implements ServerIntf {

    public ServerImpl() throws RemoteException {
    }

    public boolean areStringsEqual(String str1, String str2) throws RemoteException {
        return str1.equals(str2);
    }

    public boolean isPalindrome(String str) throws RemoteException {
        String reversedStr = new StringBuilder(str).reverse().toString();
        return str.equals(reversedStr);
    }
}

