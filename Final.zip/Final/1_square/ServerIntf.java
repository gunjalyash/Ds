import java.rmi.*;

interface ServerIntf extends Remote {
    public double calculateSquare(double number) throws RemoteException;
}

