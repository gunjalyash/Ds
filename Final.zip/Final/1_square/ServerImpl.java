import java.rmi.*;
import java.rmi.server.*;

public class ServerImpl extends UnicastRemoteObject implements ServerIntf {

    public ServerImpl() throws RemoteException {
    }

    public double calculateSquare(double number) throws RemoteException {
        double result = number * number;
        return result;
    }
}

