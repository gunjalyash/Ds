import java.rmi.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            String serverURL = "rmi://localhost/Server";
            ServerIntf serverIntf = (ServerIntf) Naming.lookup(serverURL);

            System.out.print("Enter a number: ");
            double number = sc.nextDouble();

            System.out.println("--------------- Results ---------------");
            System.out.println("Square of the number: " + serverIntf.calculateSquare(number));

        } catch (Exception e) {
            System.out.println("Exception Occurred At Client!" + e.getMessage());
        }
    }
}

